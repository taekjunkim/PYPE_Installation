/* title:   das_common.h

** author:  jamie mazer
** created: Mon Mar  4 16:41:26 2002 mazer 
** info:    dasXX_server.c common functions
** history:
**
*/

static unsigned long timestamp(int init);
static void perror2(char *s, char *file, int line);
static void mainloop(void);
static void iscan_halt(void);
static int semid;



