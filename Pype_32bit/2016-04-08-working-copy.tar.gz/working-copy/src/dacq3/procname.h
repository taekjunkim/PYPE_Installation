/* Prototypes */
void set_proc_title(char *fmt,...);
void init_set_proc_title(int argc, char *argv[], char *envp[]);

