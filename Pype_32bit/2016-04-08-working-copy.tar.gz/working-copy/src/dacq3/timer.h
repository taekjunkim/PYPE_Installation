extern void *timer_start(void);
extern void timer_clear(void *v);
extern double timer_us_elapsed(void *v);
extern int timer_ms_elapsed(void *v);

