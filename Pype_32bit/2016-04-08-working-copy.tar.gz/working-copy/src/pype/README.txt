**pype** :: **py**thon **p**hysiology **e**nvironment

This is the happydoc auto-generated documentation for pype. It's
only preliminary, but it's a start. Not that all modules are
included in the docset, but not everything is really safe for
use by end-users.

If something says **INTERNAL** or **DO NOT USE**, then you shouldn't
use it in a task or analaysis program. It might not work as you
expect (side effects) or it might change without warning.
