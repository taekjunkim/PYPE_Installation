/* title:   das08.h

** author:  jamie mazer
** created: Mon Mar  4 16:41:26 2002 mazer 
** info:    ports on das08 board
** history:
**
*/


#define ADC_Low         0x000	/* ADC-Low register */
#define ADC_High        0x001	/* ADC-High register */
#define State		0x002
