extern void catch_signals();
