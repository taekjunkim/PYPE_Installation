# -*- Mode: Python; tab-width: 4; py-indent-offset: 4; -*-
# $Id$

"""OBSOLETE; DO NOT USE

Obsolete module; backward compatibility ONLY!

Author --
James A. Mazer (mazer@socrates.berkeley.edu)

**Revision History**

- Thu Aug  8 17:23:21 2002 mazer

 - OBSOLETE, DON'T USE

"""

import sys
import pype

reporterror = pype.reporterror

sys.stderr.write("WARNING: import error is obsolete, you don't need it!\n")

