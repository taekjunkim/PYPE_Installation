# -*- Mode: Python; tab-width: 4; py-indent-offset: 4; -*-
# $Id$

"""
Ancient version of sprite.py **DO NOT USE**

Author -- James A. Mazer (james.mazer@yale.edu)

**Revision History**

- Thu Aug  8 17:23:21 2002 mazer

 - OBSOLETE, DON'T USE
"""

import sys
sys.stderr.write('WARNING: import stimlib is obsolete, use sprite instead.\n')

from sprite import *
pass
